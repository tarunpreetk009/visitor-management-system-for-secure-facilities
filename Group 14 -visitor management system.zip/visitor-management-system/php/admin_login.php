<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "visitor_management";

$conn = new mysqli($servername, $username, $password, $dbname);

$user = $_POST['admin_username'];
$pass = $_POST['admin_password'];

$sql = "SELECT * FROM admins WHERE username='$user' AND password='$pass'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
    echo "Admin Login Successful. Welcome $user!";
} else {
    echo "Login Failed. Invalid admin credentials.";
}
$conn->close();
?>
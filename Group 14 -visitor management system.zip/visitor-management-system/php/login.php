<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "visitor_management";

$conn = new mysqli($servername, $username, $password, $dbname);

$user = $_POST['username'];
$pass = $_POST['password'];

$sql = "SELECT * FROM visitors WHERE username='$user' AND password='$pass'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
    echo "Login Successful. Welcome $user!";
} else {
    echo "Login Failed. Invalid credentials.";
}
$conn->close();
?>
<?php
// Enable error reporting for debugging (remove in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if form is submitted via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "visitor_management"; // Use your DB name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("❌ Connection failed: " . $conn->connect_error);
    }

    // Collect and sanitize form data
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $user = $_POST['username'] ?? '';
    $pass = $_POST['password'] ?? '';

    // Basic validation
    if ($name && $email && $user && $pass) {
        // Insert into visitors table
        $sql = "INSERT INTO visitors (name, email, username, password) 
                VALUES ('$name', '$email', '$user', '$pass')";

        if ($conn->query($sql) === TRUE) {
            echo "✅ Visitor registered successfully!";
            // Optional: Redirect after registration
            // header("Location: ../index.html");
            // exit();
        } else {
            echo "❌ Error inserting record: " . $conn->error;
        }
    } else {
        echo "❗ All fields are required.";
    }

    $conn->close();
} else {
    echo "🚫 Invalid access method. Please use the registration form.";
}
?>
